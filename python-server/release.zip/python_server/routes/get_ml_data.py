import pandas as pd
from flask import Blueprint, request
from python_server.mlmodel.Heatmap import heatmap
from python_server.mlmodel.Boxplot import boxplot
from python_server.mlmodel.Boxplot_Xdata import boxplot_xdata

ml_data_bp = Blueprint("ml_data", __name__)

@ml_data_bp.get("/data")
def get_heatmap():
    # m1 = heatmap()
    m2 = boxplot()
    # m3 = boxplot_xdata(*request)

    return m2
